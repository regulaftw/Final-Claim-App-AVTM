// ErrorPopup.js

import React, { useState, useEffect } from 'react';
import './ErrorPopup.css';

const ErrorPopup = ({ showError } ) => {
  const [isVisible, setIsVisible] = useState(showError);

  useEffect(() => {
    setIsVisible(showError);
  }, [showError]);

  const handleAcknowledge = () => {
    setIsVisible(false);
    // You can add additional logic here if needed
    // For example, reload the screen.
    window.location.reload();
  };

  return (
    <div className={`error-popup ${isVisible ? 'visible' : ''}`}>
      <div className="popup-content">
        <p>An error occurred. Please acknowledge and reload the page.</p>
        <button onClick={handleAcknowledge}>OK</button>
      </div>
    </div>
  );
};

export default ErrorPopup;