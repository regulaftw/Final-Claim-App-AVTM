import React, { useEffect, useState } from 'react';
import './GoldClaim.css'

const GoldClaim = ({web3}) => {
    const [clickedButton1, setClickedButton1] = useState(false);
    const [clickedButton2, setClickedButton2] = useState(false);
    const [clickedButton3, setClickedButton3] = useState(false);
    const [clickedButton4, setClickedButton4] = useState(false);

    const [clickedButton1enabled, setClickedButton1enabled] = useState(false);
    const [clickedButton2enabled, setClickedButton2enabled] = useState(false);
    const [clickedButton3enabled, setClickedButton3enabled] = useState(false);
    const [clickedButton4enabled, setClickedButton4enabled] = useState(false);

    const [listofAddress, setListofAddress] = useState([]);
  
    const handleButtonClick = (buttonNumber) => {
      switch (buttonNumber) {
        case 1:
          setClickedButton1(true);
          setClickedButton2(false);
          setClickedButton3(false);
          setClickedButton4(false);
          break;
        case 2:
          setClickedButton1(false);
          setClickedButton2(true);
          setClickedButton3(false);
          setClickedButton4(false);
          break;
        case 3:
          setClickedButton1(false);
          setClickedButton2(false);
          setClickedButton3(true);
          setClickedButton4(false);
          break;
        case 4:
          setClickedButton1(false);
          setClickedButton2(false);
          setClickedButton3(false);
          setClickedButton4(true);
          break;
        default:
          break;
      }
    };

    useEffect(() => {
      //Prepare Time Var to be Used
      const now = new Date();

      const firstWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 14, 0, 0), // 8:00 AM
      };

      const firstWindowWithinTime = now >= firstWindow.startTime && now <= firstWindow.endTime
      setClickedButton1enabled(firstWindowWithinTime);
      
      const secondWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
      };
      
      const secondWindowWithinTime = now >= secondWindow.startTime && now <= secondWindow.endTime
      setClickedButton2enabled(secondWindowWithinTime);

      const thirdWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
      };

      const thirdWindowWithinTime = now >= thirdWindow.startTime && now <= thirdWindow.endTime
      setClickedButton3enabled(thirdWindowWithinTime);

      const fourthWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
      };

      const fourthWindowWithinTime =  now >= fourthWindow.startTime && now <= fourthWindow.endTime
      setClickedButton4enabled(fourthWindowWithinTime);

     

    }, []);
  
  
    return (
      <div className="centered-form">
        <br/>
        <form>
          <button type="button" onClick={() => handleButtonClick(1)}
          disabled = {!clickedButton1enabled}
          >
            Submit Number 1
          </button>
          <br/>
          <button type="button" onClick={() => handleButtonClick(2)}
          disabled = {!clickedButton2enabled}
          >
            Submit Number 2
          </button>
          <br/>
          <button type="button" onClick={() => handleButtonClick(3)}
          disabled = {!clickedButton3enabled}
          >
            Submit Number 3
          </button>
          <br/>
          <button type="button" onClick={() => handleButtonClick(4)}
          disabled = {!clickedButton4enabled}
          >
            Submit Number 4
          </button>
        </form>
        <br/>
        <div>
          {clickedButton1 && <p>You clicked Submit for Number 1, {listofAddress}</p>}
          {clickedButton2 && <p>You clicked Submit for Number 2</p>}
          {clickedButton3 && <p>You clicked Submit for Number 3</p>}
          {clickedButton4 && <p>You clicked Submit for Number 4</p>}
        </div>
      </div>
    );
  };
  
  export default GoldClaim;