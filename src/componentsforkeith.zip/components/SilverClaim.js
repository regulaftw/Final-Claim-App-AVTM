import React, { useState, useEffect } from 'react';
import './SilverClaim.css';

import ErrorPopup from './ErrorPopup';

const SilverClaim = ( {_props} ) => {
    //Parsing Props
    const props = _props;

    const [number1, setNumber1] = useState('');
    const [number2, setNumber2] = useState('');
    const [number3, setNumber3] = useState('');
    const [number4, setNumber4] = useState('');

    const [number1enabled, setNumber1enabled] = useState('');
    const [number2enabled, setNumber2enabled] = useState('');
    const [number3enabled, setNumber3enabled] = useState('');
    const [number4enabled, setNumber4enabled] = useState('');

    const [invalidSubmitt, setInvalidSubmitt] = useState('');

    //Verify User Valid User Address
    const verifyEligibleUser = (userAddress) => {
      
      //List of Eligible Address's
      const listofAddress = [0x7eFDe0F0db08862E96fa589E05ef2D184C85BCfe];

      for(var i = 0; i <listofAddress.length; i++){
        if (listofAddress[i] == userAddress){
          return true;
        }
      }

      return false;
    
    }

    //Get User Input
    const getUserInput = (listofInputs) => {
      for(var i =0; i<4; i++){
        if(listofInputs[i] != ''){
          return listofInputs[i];
        }
      }

      //Handle No Input
      window.alert("No Input was Submitted")
      window.location.reload();
    }
  
    const handleSubmit = (e) => {
      e.preventDefault();

      //Get User Input
      const listofInputs = [number1, number2, number3, number4];
      let userInput = getUserInput(listofInputs);

      //Check If Address is Eligible, Prevents Inelligible Address's from taking Part
      const { UserWalletAddress } = props;
      if (!verifyEligibleUser(UserWalletAddress)){
        //Displays Error Message and Resets
        
        setInvalidSubmitt(true);
        return;
      }

      
    };

    

    useEffect(() => {
      //Prepare Time Var to be Used
      const now = new Date();

      const firstWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 50, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 11, 52, 0), // 8:00 AM
      };

      const firstWindowWithinTime = now >= firstWindow.startTime && now <= firstWindow.endTime
      setNumber1enabled(firstWindowWithinTime);
      
      const secondWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
      };
      
      const secondWindowWithinTime = now >= secondWindow.startTime && now <= secondWindow.endTime
      setNumber2enabled(secondWindowWithinTime);

      const thirdWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
      };

      const thirdWindowWithinTime = now >= thirdWindow.startTime && now <= thirdWindow.endTime
      setNumber3enabled(thirdWindowWithinTime);

      const fourthWindow = {
        startTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
        endTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0), // 8:00 AM
      };

      const fourthWindowWithinTime =  now >= fourthWindow.startTime && now <= fourthWindow.endTime
      setNumber4enabled(fourthWindowWithinTime);

    }, []);
  
    return (
      <div className="centered-form">
        <ErrorPopup showError={invalidSubmitt}/>
        <form onSubmit={handleSubmit}>
        <br/>
          <label>
            Number 1 : 
            <input type="number" value={number1} placeholder='NFT ID?' onChange={(e) => setNumber1(e.target.value)} 
            disabled={!number1enabled} 
            />
          </label>
          <br/>
          <label>
            Number 2 :
            <input type="number" value={number2} placeholder='NFT ID?' onChange={(e) => setNumber2(e.target.value)} 
            disabled={!number2enabled}  
            />
          </label>
          <br/>
          <label>
            Number 3 :
            <input type="number" value={number3} placeholder='NFT ID?' onChange={(e) => setNumber3(e.target.value)} 
            disabled={!number3enabled}  
            />
          </label>
          <br/>
          <label>
            Number 4 :
            <input type="number" value={number4} placeholder='NFT ID?' onChange={(e) => setNumber4(e.target.value)} 
            disabled={!number4enabled}  
            />
          </label>
          <br/>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };
  
  export default SilverClaim;